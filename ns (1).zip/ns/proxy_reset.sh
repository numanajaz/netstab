#!bin/bash/

gsettings set org.gnome.system.proxy mode 'none'

