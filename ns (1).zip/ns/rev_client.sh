#!bin/bash/
sudo python3 client.py 3.141.229.167
