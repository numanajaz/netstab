#!bin/bash/

echo "1"
echo " " >> ~/Desktop/report.odt

#getting ip address
echo "1. Network Info" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt

ip=$(echo '0000' | sudo -S curl ifconfig.me)
echo "Network IP is: $ip">> ~/Desktop/report.odt

#ip=$(echo '0000' | sudo -S ip route show 0.0.0.0/0 | grep -oP 'via \K\S+')

echo " " >> ~/Desktop/report.odt
echo "Default gateway: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S ip route show 0.0.0.0/0 | grep -oP 'via \K\S+'>> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo "Inet: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S ip route get $(ip route show 0.0.0.0/0 | grep -oP 'via \K\S+') | grep -oP 'src \K\S+'>> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo "List of Live Devices: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S arp-scan -r 3 -b 2 --localnet>> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

#Locating Firewall
echo "2. Locating Firewall" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

locate=$(echo '0000' | sudo -S nmap -sX $ip| grep -w 'PORT\|open\|closed\|filtered\|MAC')
clear
echo "$locate" >> ~/Desktop/report.odt
clear
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S clear 

if echo "$locate" | grep -w 'closed\|filtered';
then
  echo "Test Verdict :		Firewall Detected" >> ~/Desktop/report.odt
else
	echo "Firewall Not Detected" >> ~/Desktop/report.odt
fi

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

#Discovery Scan
echo "3. Discovery Scan" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo '0000' | sudo -S fping $ip -c8 >> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo "Test Verdict :		Host Live" >> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

#Banner Grabbing
echo "4. Banner Grabbing" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "Service Info: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S nmap -sV --script=banner $ip >> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

#Port Scanning
echo "5. Port Scanning" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "TCP port scan vulnerability report: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S nmap -sT $ip | grep -w 'PORT\|open\|closed\|filtered\|MAC' >>  ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "FIN port scan vulnerability report: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S nmap -sF $ip | grep -w 'PORT\|open\|closed\|filtered\|MAC'>> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "NULL port scan vulnerability report: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S nmap -Pn -sN -sV -p1-65535 --script=firewall-bypass $ip | grep -w 'PORT\|VERSION\|Service Info\|open\|closed\|filtered\|MAC'>>  ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "XMAS port scan vulnerability report: " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo '0000' | sudo -S nmap -sX $ip | grep -w 'PORT\|open\|closed\|filtered\|MAC'>>  ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

# IP Spoofing
echo "6. IP Spoofing" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo '0000' | sudo -S hping3 -a "192.168.1.8" -S $ip -c 2 -p 80 >> ~/Desktop/report.odt
echo "Receiving Custom Spoofed IP Packets." >> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

# Custom Packet tests
echo "7. Custom Packets tests" >> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "Sending Random Source Packets: " >> ~/Desktop/report.odt
echo '0000' | sudo -S hping3 --rand-source -S $ip -c 10 >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "Sending Packets Flaged as Urgent: " >> ~/Desktop/report.odt
echo '0000' | sudo -S hping3 -U -S -s 5555 -c 1 $ip >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

echo "Sending Push Flag Enabled Packets: " >> ~/Desktop/report.odt
echo '0000' | sudo -S hping3 -P -S -s 5555 -c 1 $ip >> ~/Desktop/report.odt

echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

clear


