#!bin/bash/

sudo ssh -i ~/Downloads/netstab.pem ubuntu@ec2-3-141-229-167.us-east-2.compute.amazonaws.com
