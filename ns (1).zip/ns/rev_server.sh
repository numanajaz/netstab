#!bin/bash/
sudo python server.py

