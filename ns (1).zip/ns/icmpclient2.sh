#!bin/bash/
cd ~/icmptunnel
sudo ./icmptunnel 3.141.229.167 -d
sudo /sbin/ifconfig tun0 10.0.0.2 netmask 255.255.255.0
ssh -D 1080 -i ~/Downloads/netstab.pem ubuntu@10.0.0.1
gsettings set org.gnome.system.proxy.socks host "127.0.0.1"
gsettings set org.gnome.system.proxy.socks port 1080
gsettings set org.gnome.system.proxy mode 'manual'
