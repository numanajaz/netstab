#!bin/bash/

echo "4"

echo "10. Port Redirection using Local Port Forwarding">> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

chmod 400 netstab.pem
echo '0000' | sudo -S  ssh -f -N -i "netstab.pem" ubuntu@ec2-3-141-229-167.us-east-2.compute.amazonaws.com -o ExitOnForwardFailure=yes $SSH_HOST && \
echo "Test Verdict :	Port Forwarding Successful. Port Forwarding enabled. New IP through SSH Tunnel is: 3.141.229.167" >> ~/Desktop/report.odt|| \
echo "Test Verdict :	Port Forwarding Failed. Port Forwarding disabled." >> ~/Desktop/report.odt

echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt

bash proxy_reset.sh
