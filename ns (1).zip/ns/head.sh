#!bin/bash/

#enabling permissions
chmod +x bash1.sh
chmod +x ssh.sh
chmod +x http.sh
chmod +x port_redir.sh
chmod +x proxy_set.sh
chmod +x proxy_reset.sh
chmod +x runICMP.sh
chmod +x icmpserver.sh
chmod +x icmpclient.sh
chmod +x rev_server.sh
chmod +x rev_client.sh
chmod +x fragmal_r.sh
chmod +x fragmal_s.sh
chmod 400 netstab.pem

bash proxy_reset.sh

echo " "> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo "NETSTAB TEST REPORT">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt

#appends date and time in the report

date=$(date)
echo " ">> ~/Desktop/report.odt
echo "Date:	$date" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

#appends host name in the report

host=$HOSTNAME
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo "Host Name:	$host" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt

#Reconnaissance 1,2,3,4,5,6,7
timeout 4m mate-terminal --execute bash -c "bash bash1.sh"

#SSH 8
echo "8. SSH Tunneling">> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

timeout 30 mate-terminal --execute bash -c "bash ssh.sh"
echo "SSH Tunneling sucessful" >> ~/Desktop/report.odt

#HTTP 9
echo "9. HTTP Tunneling">> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt
timeout 30 mate-terminal --execute bash -c "bash http.sh"
echo "HTTP Tuneling successful">> ~/Desktop/report.odt

#Port Redirection 10
timeout 30 mate-terminal --execute bash -c "bash port_redir.sh" 

#Reverse Shell 11
echo "11. Reverse Shell">> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

chmod 400 netstab.pem

timeout 20 mate-terminal --execute bash -c "bash rev_server.sh" &
timeout 20 mate-terminal --execute bash -c "bash rev_client.sh" 

echo "Test Verdict :	Reverse Shell Successful." >> ~/Desktop/report.odt

echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt

#ICMP 12

echo "12. ICMP Tunneling">> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

timeout 20 mate-terminal --execute bash -c "bash runICMP.sh"  &
timeout 20 mate-terminal --execute bash -c "bash icmpclient.sh"

echo "Test Verdict :	ICMP Tunnel Successful." >> ~/Desktop/report.odt

echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt
echo " ">> ~/Desktop/report.odt

#Fragmented Packets 13
echo "13. Fragmented Packet Malware Transfer">> ~/Desktop/report.odt
echo "___________________________________________________________________________________" >> ~/Desktop/report.odt
echo " " >> ~/Desktop/report.odt

timeout 20 mate-terminal --execute bash -c "bash fragmal_r.sh" &
timeout 20 mate-terminal --execute bash -c "bash fragmal_s.sh"

#Report Generation in pdf form
cd ~/Desktop
xdg-open report.pdf

clear
exit
