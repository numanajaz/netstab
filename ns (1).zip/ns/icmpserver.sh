#!bin/bash/
cd icmptunnel
sudo ./icmptunnel -s -d
sudo /sbin/ifconfig tun0 10.0.0.1 netmask 255.255.255.0
