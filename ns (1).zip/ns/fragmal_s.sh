#!bin/bash/

echo "10"

echo '0000' | sudo -S  hping3 -I wlan0 localhost --frag --sign signature -d 1000 -c 1 -E malware.odt 

echo " ">> ~/Desktop/report.odt
echo "Test Verdict:	Malware File Transfered Successfully.">> ~/Desktop/report.odt
