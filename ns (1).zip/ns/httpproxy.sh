#!bin/bash/

gsettings set org.gnome.system.proxy.http host "127.0.0.1"
gsettings set org.gnome.system.proxy.http port 9999
gsettings set org.gnome.system.proxy mode 'manual'

