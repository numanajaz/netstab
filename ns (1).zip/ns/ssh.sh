#!bin/bash/

chmod 400 ~/Downloads/netstab.pem
ssh -D 8080 -i ~/Downloads/netstab.pem ubuntu@ec2-3-141-229-167.us-east-2.compute.amazonaws.com






