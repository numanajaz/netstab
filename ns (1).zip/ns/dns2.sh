#!bin/bash/

sshuttle --dns -r ubuntu@3.141.229.167 0.0.0.0/0
