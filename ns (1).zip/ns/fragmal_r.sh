#!bin/bash/

echo "9"
echo '0000' | sudo -S sudo hping3 -i wlan0 --listen signature --frag
