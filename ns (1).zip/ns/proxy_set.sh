#!bin/bash/

gsettings set org.gnome.system.proxy.socks host "127.0.0.1"
gsettings set org.gnome.system.proxy.socks port 8080
gsettings set org.gnome.system.proxy mode 'manual'


