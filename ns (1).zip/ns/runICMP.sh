#!bin/bash/

echo "7"
chmod 400 ~/Downloads/netstab.pem

echo '0000' | sudo -S sudo ssh -i ~/Downloads/netstab.pem ubuntu@ec2-3-141-229-167.us-east-2.compute.amazonaws.com 'bash -i -s'< icmpserver.sh
 
